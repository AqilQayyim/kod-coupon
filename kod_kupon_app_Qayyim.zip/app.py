from flask import Flask, render_template, request, redirect, url_for, session
import random
import string

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Contoh kod rahsia dan maksud
kod_rahsia = {
    "v0135": "Percutian ke Langkawi",
    "abc123": "Diskaun 50%",
    "v133h098jd7js5": "Hadiah Misteri"
}

# Simpan siapa yang dah guna kod
digunakan = {}
kupon_dijana = {}

# Halaman utama
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        nama = request.form['nama']
        kod = request.form['kod']

        if kod in kod_rahsia:
            if kod in digunakan:
                return render_template('index.html', mesej="Kod ini sudah digunakan.", maksud=None)
            maksud = kod_rahsia[kod]
            kupon = jana_kupon()
            digunakan[kod] = nama
            kupon_dijana[nama] = kupon
            return render_template('index.html', mesej=None, maksud=maksud, kupon=kupon)
        else:
            return render_template('index.html', mesej="Kod tidak sah.", maksud=None)
    return render_template('index.html', mesej=None, maksud=None)

# Fungsi jana kupon
def jana_kupon():
    return "v" + ''.join(random.choices(string.ascii_lowercase + string.digits, k=5)) + "-" +            ''.join(random.choices(string.ascii_lowercase + string.digits, k=6)) + "-" +            ''.join(random.choices(string.ascii_lowercase + string.digits, k=6)) + "-" +            ''.join(random.choices(string.ascii_lowercase + string.digits, k=6)) + "-" +            ''.join(random.choices(string.ascii_lowercase + string.digits, k=4))

# Halaman admin
@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'rahsia123':
            session['admin'] = True
            return redirect(url_for('dashboard'))
        else:
            return render_template('admin.html', error='Salah nama atau kata laluan')
    return render_template('admin.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin'))
    return render_template('dashboard.html', digunakan=digunakan, kupon=kupon_dijana)
