from flask import Flask, request, render_template_string
import uuid

app = Flask(__name__)

used_codes = {}
coupon_codes = {}

@app.route("/", methods=["GET", "POST"])
def index():
    message = ""
    if request.method == "POST":
        name = request.form.get("name")
        secret_code = request.form.get("secret_code")
        if not name or not secret_code:
            message = "Sila isi semua maklumat."
        elif secret_code in used_codes:
            message = f"Code '{secret_code}' dah digunakan oleh {used_codes[secret_code]}."
        else:
            coupon = str(uuid.uuid4())
            used_codes[secret_code] = name
            coupon_codes[name] = coupon
            message = f"Tahniah {name}! Kod kupon anda: {coupon}"
    return render_template_string("""
        <h2>Masukkan Nama dan Kod Rahsia</h2>
        <form method="post">
            Nama: <input type="text" name="name"><br><br>
            Kod Rahsia: <input type="text" name="secret_code"><br><br>
            <input type="submit" value="Maksudkan Kod">
        </form>
        <p>{{ message }}</p>
    """, message=message)

@app.route("/admin")
def admin():
    return {
        "used_codes": used_codes,
        "coupon_codes": coupon_codes
    }

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=3000)
